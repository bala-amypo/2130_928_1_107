package com.example.demo.security;

public class JwtConstants {
    public static final String SECRET_KEY =
            "my-super-secret-key-my-super-secret-key";
}
