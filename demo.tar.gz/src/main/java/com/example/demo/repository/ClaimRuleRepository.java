package com.example.demo.repository;

import com.example.demo.model.ClaimRule;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClaimRuleRepository extends JpaRepository<ClaimRule, Long> {
    // Standard JpaRepository methods are sufficient
}